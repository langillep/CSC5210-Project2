/* 
 * File:   LangilleDrawing.h
 * Author: P. Langille
 *
 * Created on October 10, 2017, 7:33 PM
 */

#ifndef DRAWING_H
#define DRAWING_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "LangilleShader.hpp"

using glm::vec3;
using glm::vec4;

class Drawing {
public:
    virtual void draw(Shader*)=0; //will be overridden
    virtual void addPoint(vec3)=0; //will be overridden primarily for Pen
    virtual int getNumPoints()=0;
    virtual void setColor(vec3)=0;
};

#endif /* DRAWING_H */

