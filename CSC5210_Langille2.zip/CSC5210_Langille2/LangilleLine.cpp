/* 
 * File:   LangilleLine.cpp
 * Author: P. Langille
 * 
 * Created on October 10, 2017, 7:30 PM
 */

#include "LangilleLine.h"
#include "LangilleDrawing.h"

/**
 * Description: Initializing the line given the two end points and the color
 * @param _a
 * @param _b
 * @param col
 */
Line::Line(vec3 _a, vec3 _b, vec3 col) {
    a = _a;
    b = _b;
    color = col;
    
    //list of coordinates
    GLfloat verts[] = {a.x, a.y, a.z, 
        b.x, b.y, b.z,};

    // Set up the VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof (verts), verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);
}

/**
 * Description: draws the line
 */
void Line::draw(Shader* s){
    
    glBindVertexArray(VAO);

    // Make the color the fill color
    GLint c = s -> GetVariable("color");
    s -> SetVector3(c, 1, &color[0]);
    glDrawArrays(GL_LINES, 0, 3);

    glBindVertexArray(0);
}

void Line::addPoint(vec3 p){}
int Line::getNumPoints(){
    return 0;
}

void Line::setColor(vec3 c){
    color = c;
}