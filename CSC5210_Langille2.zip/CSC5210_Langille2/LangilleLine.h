/* 
 * File:   LangilleLine.h
 * Author: P. Langille
 *
 * Created on October 10, 2017, 7:30 PM
 */

#ifndef LINE_H
#define LINE_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "LangilleShader.hpp"
#include "LangilleDrawing.h"

using glm::vec3;
using glm::vec4;

class Line: public Drawing {
public:
    Line(vec3, vec3, vec3);    // two end-points and the color
    void draw(Shader*);        //draws the line
    void addPoint(vec3);
    int getNumPoints();
    void setColor(vec3);
private:
    vec3 a;
    vec3 b;        ///two end-points
    vec3 color;       //color of the line
    
     // The VAO and VBO
    GLuint VAO;
    GLuint VBO;

};

#endif /* LINE_H */

