/* 
 * File:   LangilleQuad.h
 * Author: P. Langille
 *
 * Created on October 10, 2017, 7:30 PM
 */

#ifndef QUAD_H
#define QUAD_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "LangilleShader.hpp"
#include "LangilleDrawing.h"
#include "LangilleTriangle.hpp"
#include <vector>

using glm::vec3;
using glm::vec4;

class Quad: public Drawing {
public:
    Quad(vec3, vec3, vec3);  //initializes using users selected points and color
    void draw(Shader*);   // draws the quad
    void addPoint(vec3);
    int getNumPoints();
    void setColor(vec3);
private:
    vec3 a, b, c, d;  //vertices of the quad
    std::vector<Triangle*> t;   //keeps track of the triangles that make up quad
    vec3 color;   //the color of the quad
    
      // The VAO and VBO
    GLuint VAO;
    GLuint VBO;

};

#endif /* QUAD_H */

