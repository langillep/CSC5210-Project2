/* 
 * File:   LangilleDrawing.cpp
 * Author: P.Langille
 * 
 * Created on October 10, 2017, 7:33 PM
 */

#include "LangilleDrawing.h"


//abstract class
