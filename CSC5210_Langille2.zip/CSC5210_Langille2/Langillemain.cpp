/* 
 * File:   Langillemain.cpp
 * Author: P. Langille
 *
 * Created on October 8, 2017, 5:06 PM
 */

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <iostream>
#include <ctime>
#include <cstdio>
#include <glm/glm.hpp>
#include <cmath>

// Local Utilities Includes
#include "LangilleShader.hpp"
#include "LangilleDrawing.h"
#include "LangilleSketch.h"
#include "LangilleLine.h"
#include "LangillePen.h"
#include "LangilleQuad.h"
#include "LangilleTriangle.hpp"

using std::cerr;
using std::endl;
using glm::vec3;
using glm::mat4;


// Macro to help convert to proper type for buffer offsets
#define BUFFER_OFFSET(i) ((void*)(intptr_t)(i))

// The total number of buffers
const int vPosition = 0;


sf::Vector2i curPos;
Shader* s;
Sketch* sketch = new Sketch();
Drawing* d;
int GUIState = 0;
int numUndos = 0;
Drawing* GUIButtonList[19];
Triangle* GUITris[4];
int quadClicks = 0;
int LineClicks = 0;
int penClick = 0;
vec3 curColor = vec3(1.0f, 1.0f, 1.0f);
Drawing* pen = new Pen(curColor);
vec3 previousPoint;

/**
 * Description: converts coordinate to GL coordinate
 * @param x
 * @param y
 * @param window
 * @return 
 */
vec3 toGL(float x, float y, sf::Window& window)
{
    vec3 g;
    g.x = (x - (window.getSize().x / 2.0)) / (window.getSize().x / 2.0);
    g.y = -1 * ((y - (window.getSize().y / 2.0)) / (window.getSize().y / 2.0));
    g.z = 0.0;
    return g;
}

void init(){
    
    //creates the boxes for my "GUI"
    Drawing* GUIClearButton = new Quad(vec3(-0.9, 0.95, 0.0), vec3(-0.7, 0.7, 0.0), vec3(0.5f, 0.5f, 0.5f));
    Line* GUISep1 = new Line(vec3(-0.7, 0.7, 0.0), vec3(-0.7, 0.95, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIUndoButton = new Quad(vec3(-0.7, 0.7, 0.05), vec3(-0.5, 0.95, 0.05), vec3(0.5f, 0.5f, 0.5f));
    Line* GUISep2 = new Line(vec3(-0.5, 0.7, 0.0), vec3(-0.5, 0.95, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIPenButton = new Quad(vec3(-0.5, 0.95, 0.05), vec3(-0.3, 0.7, 0.05), vec3(0.5f, 0.5f, 0.5f));
    Line* GUISep3 = new Line(vec3(-0.3, 0.7, 0.0), vec3(-0.3, 0.95, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIQuadButton = new Quad(vec3(-0.3, 0.7, 0.05), vec3(-0.1, 0.95, 0.05), vec3(0.5f, 0.5f, 0.5f));
    Line* GUISep4 = new Line(vec3(-0.1, 0.7, 0.0), vec3(-0.1, 0.95, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUILineButton = new Quad(vec3(-0.1, 0.95, 0.05), vec3(0.1, 0.7, 0.05), vec3(0.5f, 0.5f, 0.5f));
    Line* GUISep5 = new Line(vec3(0.1, 0.7, 0.0), vec3(0.1, 0.95, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIRedButton = new Quad(vec3(0.1, 0.7, 0.0), vec3(0.3, 0.95, 0.0), vec3(1.0f, 0.0f, 0.0f));
    Quad* GUIGreenButton = new Quad(vec3(0.3, 0.95, 0.0), vec3(0.5, 0.7, 0.0), vec3(0.0f, 1.0f, 0.0f));
    Quad* GUIBlueButton = new Quad(vec3(0.5, 0.7, 0.0), vec3(0.7, 0.95, 0.0), vec3(0.0f, 0.0f, 1.0f));
    Quad* GUIWhiteButton = new Quad(vec3(0.7, 0.95, 0.0), vec3(0.9, 0.7, 0.0), vec3(1.0f, 1.0f, 1.0f));
    Quad* GUIQuadSymbol = new Quad(vec3(-0.25, 0.75, 0.0), vec3(-0.15, 0.9, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Line* GUILineSymbol = new Line(vec3(-0.05, 0.75, 0.0), vec3(0.05, 0.9, 0.0), vec3(0.0f, 0.0f, 0.0f));
    
    //creates the undo symbol
    Quad* GUIUndo1 = new Quad(vec3(-0.675, 0.725, 0.0), vec3(-0.55, 0.75, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIUndo2 = new Quad(vec3(-0.55, 0.75, 0.0), vec3(-0.575, 0.875, 0.0), vec3(0.0f, 0.0f, 0.0f));
    Quad* GUIUndo3 = new Quad(vec3(-0.66, 0.85, 0.0), vec3(-0.575, 0.875, 0.0), vec3(0.0f, 0.0f, 0.0f));
    
    GUIButtonList[0] = GUIClearButton;
    GUIButtonList[1] = GUIUndoButton;
    GUIButtonList[2] = GUIPenButton;
    GUIButtonList[3] = GUIQuadButton;
    GUIButtonList[4] = GUILineButton;
    GUIButtonList[5] = GUIRedButton;
    GUIButtonList[6] = GUIGreenButton;
    GUIButtonList[7] = GUIBlueButton;
    GUIButtonList[8] = GUIWhiteButton;
    GUIButtonList[9] = GUIQuadSymbol;
    GUIButtonList[10] = GUILineSymbol;
    GUIButtonList[11] = GUISep1;
    GUIButtonList[12] = GUISep2;
    GUIButtonList[13] = GUISep3;
    GUIButtonList[14] = GUISep4;
    GUIButtonList[15] = GUISep5;
    GUIButtonList[16] = GUIUndo1;
    GUIButtonList[17] = GUIUndo2;
    GUIButtonList[18] = GUIUndo3;
    
    //creates pen symbol and the triangle on the undo symbol
    Triangle* t1 = new Triangle(vec3(-0.425, 0.75, 0.0), vec3(-0.475, 0.725, 0.0), vec3(-0.45, 0.775, 0.0));
    Triangle* t2 = new Triangle(vec3(-0.45, 0.775, 0.0), vec3(-0.425, 0.75, 0.0), vec3(-0.35, 0.9, 0.0));
    Triangle* t3 = new Triangle(vec3(-0.35, 0.9, 0.0), vec3(-0.325, 0.875, 0.0), vec3(-0.425, 0.75, 0.0));
    Triangle* t4 = new Triangle(vec3(-0.66, 0.8, 0.0), vec3(-0.68, 0.865, 0.0), vec3(-0.66, 0.9, 0.0));
    GUITris[0] = t1;
    GUITris[1] = t2;
    GUITris[2] = t3;
    GUITris[3] = t4;
    for(int i = 0; i < 3; i++)
    {
        GUITris[i]->setFillColor(vec3(0.05f, 0.05f, 0.05f));
        GUITris[i]->setBorderColor(vec3(0.0f, 0.0f, 0.0f));
    }
    GUITris[3]->setFillColor(vec3(0.0f, 0.0f, 0.0f));
    
    
    string shaders[] = {"vertices.vert", "fragments.frag"};
    s = new Shader(shaders, true);
}
// This function handles keyboard and mouse events
void handleEvents(sf::Window& window)
{
    sf::Event event;
 
    
    //Pen* p = new Pen(curColor);
   
    // While there are still events.
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
        {
            window.close();
        }
        else if (event.type == sf::Event::Resized)
        {
            glViewport(0, 0, event.size.width, event.size.height);
        }
        // Keyboard pressed
        else if (event.type == sf::Event::KeyReleased)
        {
            if (event.key.code == sf::Keyboard::Q)
            {
                window.close();
            } 
        }
        if(GUIState == 0)
        {
            if( sf::Mouse::isButtonPressed(sf::Mouse::Left) )
            {
                curPos = sf::Mouse::getPosition(window);
                if(!(toGL(curPos.x, curPos.y, window).y < 0.95 && toGL(curPos.x, curPos.y, window).y > 0.7)){
                    if(penClick == 0)
                    {
                        d = new Pen(curColor); //creates new pen
                        //adds the current point to the Pen object
                        d->addPoint(toGL(curPos.x, curPos.y, window)); 
                        penClick++; //increments pen click
                        sketch->addDrawing(d);//adds drawing to the vector
                    }
                    else{
                        //adds a point to the pen object at the end of the vector
                        sketch->get(sketch->getNumDrawings() - 1)->addPoint(toGL(curPos.x, curPos.y, window));
                    }
                }
            }
        }
        // Mouse clicks
        // If there's mouse input, handle the camera
        if ( event.type == sf::Event::MouseButtonReleased )
        {
            // Get the position of the mouse
            if(event.mouseButton.button == sf::Mouse::Right)
            {
                curPos = sf::Mouse::getPosition(window);
                if(GUIState == 2 && LineClicks > 0)
                {
                    d = new Line(previousPoint, toGL(curPos.x, curPos.y, window), curColor);
                    sketch->addDrawing(d);
                    LineClicks = 0;
                }
            }
            // If the left mouse is down
            if (event.mouseButton.button == sf::Mouse::Left)
            {
                curPos = sf::Mouse::getPosition(window);
                vec3 a = toGL(curPos.x, curPos.y, window);
                if(a.y < 0.95 && a.y > 0.7){
                    if((a.x < -0.7 && a.x > -.9) && (a.y < 0.95 && a.y > 0.7))
                    {
                        //clear sketch
                        sketch->clearDrawings();
                        numUndos = 0;
                    }
                    else if((a.x < -0.5) && (a.x > -0.7))
                    {
                        //undo pop_back() add 1 to undo if a drawing is added to sketch
                        if(!(numUndos - 1 < 0))
                        {
                            sketch->undo();
                            numUndos--;
                        }
                        
                    }
                    else if((a.x < -0.3) && (a.x > -0.5))
                    {
                        //sets GUIState to 0 if the Pen is selected
                        GUIState = 0;
                    }
                    else if((a.x < -0.1) && (a.x > -0.3))
                    {
                        //sets GUIState to 1 if the Quad button is selected
                        GUIState = 1;
                    }
                    else if((a.x < 0.1) && (a.x > -0.1))
                    {
                        //sets GUIState to 2 if the Line button is selected
                        GUIState = 2;
                    }
                    else if((a.x < 0.3) && (a.x > 0.1))
                    {
                        //sets the color to red
                        curColor = vec3(1.0f, 0.0f, 0.0f);
                    }
                    else if((a.x < 0.5) && (a.x > 0.3))
                    {
                        //sets the color to green
                        curColor = vec3(0.0f, 1.0f, 0.0f);
                    }
                    else if((a.x < 0.7) && (a.x > 0.5))
                    {
                        //sets the color to blue
                        curColor = vec3(0.0f, 0.0f, 1.0f);
                    }
                    else if((a.x < 0.9) && (a.x > 0.7))
                    {
                        //sets the color to white
                        curColor = vec3(1.0f, 1.0f, 1.0f);
                    }
                }
                else{
                    if(GUIState == 0){
                        //Pen
                        sketch->get(sketch->getNumDrawings() - 1)->addPoint(toGL(curPos.x, curPos.y, window));
                        if(numUndos < 10){
                            numUndos++; // add one to the number of undos that can be performed
                        }
                        previousPoint = toGL(curPos.x, curPos.y, window);
                        //reset penClick
                        penClick = 0;
                    }
                    else if(GUIState == 1)
                    {
                        //Quad
                        if(quadClicks + 1 > 1)
                        {
                            //create a new Quad
                            d = new Quad(previousPoint, toGL(curPos.x, curPos.y, window), curColor);
                            //add the Quad to the vector
                            sketch->addDrawing(d);
                            //reset quadClicks
                            quadClicks = 0; 
                            if(numUndos < 10)
                            {
                                numUndos++;
                            }
                            previousPoint = toGL(curPos.x, curPos.y, window);
                        }
                        else{
                            previousPoint = toGL(curPos.x, curPos.y, window);
                            quadClicks++; //increment quadClicks
                        }
                    }
                    else if(GUIState == 2)
                    {
                        //Line
                        if(LineClicks > 0){
                            if(previousPoint.x != toGL(curPos.x, curPos.y, window).x && previousPoint.y != toGL(curPos.x, curPos.y, window).y)
                            {
                                //creates a new Line using the first click and the second
                                d = new Line(previousPoint, toGL(curPos.x, curPos.y, window), curColor);
                                sketch->addDrawing(d);
                                //increments the number of possible undos 
                                if(numUndos < 10)
                                {
                                    numUndos++;
                                }
                                previousPoint = toGL(curPos.x, curPos.y, window);
                            }
                            LineClicks++;//incrementsLineClicks
                        }
                        else{
                            previousPoint = toGL(curPos.x, curPos.y, window);
                            LineClicks++; // increments LineClicks
                        }
                    }
                }
            }   
            
        }
    }
}

// Function to draw stuff
void display(sf::Window& window)
{
    while (window.isOpen())
    {
       
        // First, make sure you handle the events
        handleEvents(window);
        
        // Clears the given framebuffer (in this case, color)
        // Could set color to clear to with glClearColor, default is black
        // Where should we put a call to clearColor?
        //glClear(GL_COLOR_BUFFER_BIT);

        
        for(int i = 0; i < 19; i++){
            GUIButtonList[i]->draw(s);
        }
        
        for(int j= 0; j < 4; j++)
        {
            GUITris[j]->draw(s);
        }
        sketch->draw(s);

        window.display();
        
        
    }
}

int main(int argc, char** argv) {

    // Need ContextSettings object to set window settings
    sf::ContextSettings settings;   
    settings.antialiasingLevel = 8;

    // Create a new SFML window
    sf::Window window(sf::VideoMode(1000, 800),
            "Pat's Paint Place", sf::Style::Default, settings);

    // To be safe, we’re using glew’s experimental stuff.
    glewExperimental = GL_TRUE;
    // Initialize and error check GLEW
    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        // If something went wrong, print the error message
        fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
    }

    init();

    display(window);
    

    return 0;
}

