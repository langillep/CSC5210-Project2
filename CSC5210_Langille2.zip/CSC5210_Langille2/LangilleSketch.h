/* 
 * File:   Sketch.h
 * Author: P. Langille
 *
 * Created on October 10, 2017, 7:42 PM
 */

#ifndef SKETCH_H
#define SKETCH_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "LangilleShader.hpp"
#include "LangilleDrawing.h"
#include "LangillePen.h"
#include "LangilleQuad.h"
#include "LangilleLine.h"
#include <vector>

using glm::vec3;
using glm::vec4;

class Sketch {
public:
    Sketch();   //tracks the drawings on the screen
    void draw(Shader*);  //draws all of the elements onto the screen
    void addDrawing(Drawing*);  //adds a drawing to the list
    void undo();        //pops off the last element from the vector
    void clearDrawings();  //clears the vector
    int getNumDrawings(); //returns the number of drawings in the vector
    Drawing* get(int);  //returns the drawing at the given index

private:
    int numDrawings;  //number of drawings in the vector
    std::vector<Drawing*> drawings;  //list of all of the drawings

};

#endif /* SKETCH_H */

