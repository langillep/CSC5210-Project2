/* 
 * File:   LangilleSketch.cpp
 * Author: P. Langille
 * 
 * Created on October 10, 2017, 7:42 PM
 */

#include "LangilleSketch.h"

/**
 * initializes the number of drawings to 0
 */
Sketch::Sketch() {
    numDrawings = 0;
}

/**
 * Description: Draws each drawing in vector
 * @param s
 */
void Sketch::draw(Shader* s)
{
    for(int i = 0; i < numDrawings; i++)
    {
        drawings[i]->draw(s);
    }
}

/**
 * Description: adds a given drawing to the vector
 * @param d
 */
void Sketch::addDrawing(Drawing* d){
    drawings.push_back(d);
    numDrawings++;
}

/**
 * Description: pops the last element off of the vector
 */
void Sketch::undo()
{
    drawings.pop_back();
    numDrawings--;
}

/**
 * Description: clears the vector
 */
void Sketch::clearDrawings(){
    drawings.clear();
    numDrawings = 0;
    //drawings.shrink_to_fit();
}

/**
 * Description: returns the number of drawings in the vector
 */
int Sketch::getNumDrawings(){
    return numDrawings;
}

/**
 * Description: returns the element at index i
 * @param i
 * @return 
 */
Drawing* Sketch::get(int i){
    return drawings[i];
}