/* 
 * File:   LangillePen.cpp
 * Author: P. Langille
 * 
 * Created on October 10, 2017, 7:38 PM
 */

#include "LangillePen.h"
#include "LangilleDrawing.h"

/**
 * Description: initializes the Pen drawing with an initial point and a color
 * @param p1
 * @param col
 */
Pen::Pen(vec3 col) {
    color = col;
    numPoints = 0;
}

void Pen::setColor(vec3 c){
    color = c;
}
/**
 * Description: draws the pen drawing
 */
void Pen::draw(Shader* s){
    for(int i = 0; i < numPoints; i++){
        glBindVertexArray(VAO);

        // Make the color the fill color
        GLint c = s -> GetVariable("color");
        s -> SetVector3(c, 1, &color[0]);
        glDrawArrays(GL_POINTS, 0, 3);

        glBindVertexArray(0);
    }
}

/**
 * Description: adds the given point to the vector
 * @param p
 */
void Pen::addPoint(vec3 p)
{
    std::cout << "point = " << p.x << ", " << p.y << ", " << p.z << endl;
    points.push_back(p); //adds point to the end of the vector
    numPoints++;
    GLfloat point[numPoints * 3];
    int j = 0;
    //updates the points
    for(int i = 0; i < numPoints; i++)
    {
        point[j] = points[i].x;
        point[j+1] = points[i].y;
        point[j+2] = points[i].z;
        j += 3;
    }
    // Set up the VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof (point), point, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);
}

int Pen::getNumPoints(){
    return numPoints;
}
