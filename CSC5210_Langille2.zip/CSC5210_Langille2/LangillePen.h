/* 
 * File:   LangillePen.h
 * Author: P. Langille
 *
 * Created on October 10, 2017, 7:38 PM
 */

#ifndef PEN_H
#define PEN_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/vec3.hpp>
#include "LangilleShader.hpp"
#include <vector>
#include "LangilleDrawing.h"

using glm::vec3;
using glm::vec4;

class Pen: public Drawing {
public:
    Pen(vec3);   //initializes the pen object with initial point and color
    void draw(Shader*);   //draws the sketch
    void addPoint(vec3);   //adds a point to be colored
    int getNumPoints();  //returns the number of points drawn
    void setColor(vec3);
private:
    int numPoints;        //number of points colored 
    vec3 color;           //the color of the drawing
    std::vector<vec3> points;   //list of the points
    
      // The VAO and VBO
    GLuint VAO;
    GLuint VBO;

};

#endif /* PEN_H */

