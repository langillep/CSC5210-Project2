/**
 * Written by Christopher Stuetzle
 */

#include "LangilleTriangle.hpp"
#include "LangilleDrawing.h"


Triangle::Triangle(vec3 _a, vec3 _b, vec3 _c)
{
    a = _a;
    b = _b;
    c = _c;

    GLfloat verts[] = {a.x, a.y, a.z,
        b.x, b.y, b.z,
        c.x, c.y, c.z};

    // Set up the VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(GL_ARRAY_BUFFER, sizeof (verts), verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);


}

// Setters for the colors
void Triangle::setFillColor( vec3 fC ) {
    fillColor = fC;
    borderColor = fillColor;
}
void Triangle::setBorderColor( vec3 bC ) {
    borderColor = bC;
}

// The draw function
void Triangle::draw(Shader* s)
{
    glBindVertexArray(VAO);

    // Make the color the fill color
    GLint c = s -> GetVariable("color");
    s -> SetVector3(c, 1, &fillColor[0]);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    // Switch to border color for the outline
    s -> SetVector3(c, 1, &borderColor[0]);
    glDrawArrays(GL_LINE_LOOP, 0, 3);

    glBindVertexArray(0);

}
