/* 
 * File:   LangilleQuad.cpp
 * Author: P. Langille
 * 
 * Created on October 10, 2017, 7:30 PM
 */

#include "LangilleQuad.h"
#include "LangilleDrawing.h"

/**
 * Description: initializes the quad with two given vertices and a color
 * @param _a
 * @param _b
 * @param col
 */
Quad::Quad(vec3 _a, vec3 _b, vec3 col) {
    a = _a;
    b = _b;
    color = col;
    c = vec3(a.x, b.y, a.z);
    d = vec3(b.x, a.y, a.z);
    Triangle* t1 = new Triangle(a, b, c);
    Triangle* t2 = new Triangle(a, b, d);
    t1->setFillColor(color);
    t2->setFillColor(color);
    t.push_back(t1);
    t.push_back(t2);
    /*std::cout << "Quad = " << a.x << ", " << a.y <<endl;
    std::cout << b.x << ", " <<b.y <<endl;
    std::cout << c.x << ", " <<c.y << endl;
    std::cout << d.x <<", " << d.y << endl;*/
}

/**
 * Description: draws the two triangles that make up the quad
 */
void Quad::draw(Shader* s){

    t[0]->draw(s);
    t[1]->draw(s);
}

void Quad::addPoint(vec3 p){}
int Quad::getNumPoints(){
    return 0;
}

void Quad::setColor(vec3 c){
    color = c;
}
